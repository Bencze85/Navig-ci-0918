document.getElementById("openmenu").onclick() 
{
    document.getElementById("navigáció").classList.toggle("nyitva");
}
