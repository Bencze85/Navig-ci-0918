
const App = () => {
  return (
    <>
     <h1>Kezdőlap</h1>
    </>
  )
}
export default App
