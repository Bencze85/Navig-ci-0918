import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import NavigationHeader from "./components/NavigationHeader";
import Footer from "./components/Footer";
import Blog from "./components/Blog";
import Contact from "./components/Contact";
import Home from "./components/Home"; 

const App = () => {
  return (
    <Router>
      <NavigationHeader />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/:id" element={<div>Blog részletesen</div>} />
          <Route path="/works" element={<div>Munkáim</div>} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </main>
      <Footer />
    </Router>
  );
};

export default App;
