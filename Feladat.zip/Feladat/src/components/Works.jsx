import React from "react";

const Works = () => {
  
  const projects = [
    {
      id: 1,
      title: "Weboldal Design",
      description: "Egy szép és reszponzív weboldal tervezése.",
      imageUrl: "assets/project1.jpg", 
      link: "/projects/1"
    },
    {
      id: 2,
      title: "Mobil Applikáció",
      description: "Mobil alkalmazás tervezése és fejlesztése.",
      imageUrl: "assets/project2.jpg", 
      link: "/projects/2"
    },
    {
      id: 3,
      title: "E-kereskedelmi Platform",
      description: "Egy teljes e-kereskedelmi rendszer megvalósítása.",
      imageUrl: "assets/project3.jpg", 
      link: "/projects/3"
    }
  ];

  return (
    <div>
      <h1>Munkáim</h1>
      <div className="works-container">
        {projects.map((project) => (
          <div key={project.id} className="work-item">
            <img src={project.imageUrl} alt={project.title} />
            <h2>{project.title}</h2>
            <p>{project.description}</p>
            <a href={project.link} className="btn">További információ</a>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Works;