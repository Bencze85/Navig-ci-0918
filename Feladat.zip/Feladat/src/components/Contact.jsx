import React, { useState } from "react";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Üzenet elküldve!");
  };

  return (
    <div>
      <h1>Kapcsolat</h1>
      <form onSubmit={handleSubmit}>
        <label>
          Név:
          <input type="text" name="name" value={formData.name} onChange={handleChange} required />
        </label>
        <label>
          E-mail:
          <input type="email" name="email" value={formData.email} onChange={handleChange} required />
        </label>
        <label>
          Üzenet:
          <textarea name="message" value={formData.message} onChange={handleChange} required></textarea>
        </label>
        <button type="submit">Küldés</button>
      </form>
    </div>
  );
};

export default Contact;