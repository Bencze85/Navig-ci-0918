export default function Footer() {
    return (
      <footer className="footer">
        <p>&copy; 2025 My Portfolio. Minden jog fenntartva.</p>
      </footer>
    );
  }