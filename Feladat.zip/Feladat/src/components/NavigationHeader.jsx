import { NavLink } from "react-router-dom";
import "../index.css";

export default function NavigationHeader() {
  return (
    <nav className="nav">
      <ul>
        <li><NavLink to="/" className={({ isActive }) => isActive ? "active" : ""}>Kezdőlap</NavLink></li>
        <li><NavLink to="/blog" className={({ isActive }) => isActive ? "active" : ""}>Blog</NavLink></li>
        <li><NavLink to="/works" className={({ isActive }) => isActive ? "active" : ""}>Munkáim</NavLink></li>
        <li><NavLink to="/contact" className={({ isActive }) => isActive ? "active" : ""}>Kapcsolat</NavLink></li>
      </ul>
    </nav>
  );
}