import React from "react";
import { Link } from "react-router-dom";

const Blog = () => {
  const blogPosts = [
    { id: 1, title: "Első bejegyzés" },
    { id: 2, title: "Második bejegyzés" },
    { id: 3, title: "Harmadik bejegyzés" }
  ];

  return (
    <div>
      <h1>Blogok</h1>
      <ul>
        {blogPosts.map(post => (
          <li key={post.id}>
            <Link to={`/blog/${post.id}`} className="blog-link">{post.title}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Blog;
  