import React from "react";
import { Link } from "react-router-dom";
import myImage from "../assets/john.png";
import facebookIcon from "../assets/facebook.svg"; 
import instagramIcon from "../assets/instagram.svg";
import linkedinIcon from "../assets/linkedin.svg"; 
import twitterIcon from "../assets/twitter.svg"; 

const Home = () => {
  return (
    <div className="home-container">
      <section className="hero-section">
        <div className="hero-text">
          <h1>Üdvözlöm a portfóliómban!</h1>
          <p>Szép és reszponzív weboldalakat tervezek és fejlesztek.</p>
          <Link to="/works" className="btn">Tekintse meg munkáimat</Link>
        </div>
        <div className="hero-image">
          <img src={myImage} alt="Bemutatkozó kép" />
        </div>
      </section>

      <section className="about-section">
        <h2>Rólam</h2>
        <p>
          Üdvözlöm! Én vagyok a <strong>Szuper Fejlesztő</strong>, weboldalak és mobil applikációk
          tervezésével és fejlesztésével foglalkozom. Az általam készített projektek nemcsak
          esztétikusak, hanem felhasználóbarátok és reszponzívak is.
        </p>
      </section>

      <section className="services-section">
        <h2>Szolgáltatások</h2>
        <ul>
          <li>Weboldal tervezés és fejlesztés</li>
          <li>Reszponzív dizájn</li>
          <li>SEO optimalizálás</li>
          <li>Web alkalmazások</li>
        </ul>
      </section>

      <section className="cta-section">
        <h2>Kapcsolat</h2>
        <p>Ha szeretne velem dolgozni, ne habozzon kapcsolatba lépni velem!</p>
        <Link to="/contact" className="btn">Kapcsolatfelvétel</Link>
      </section>
    </div>
  );
};

export default Home;

  