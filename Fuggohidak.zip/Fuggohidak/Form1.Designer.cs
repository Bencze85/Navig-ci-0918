﻿
namespace Fuggohidak
{
    partial class frmFuggohidak1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txbdarab = new System.Windows.Forms.TextBox();
            this.rbn2000utan = new System.Windows.Forms.RadioButton();
            this.rbn2000elott = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txbHely = new System.Windows.Forms.TextBox();
            this.txbOrszag = new System.Windows.Forms.TextBox();
            this.txbHossz = new System.Windows.Forms.TextBox();
            this.txbEv = new System.Windows.Forms.TextBox();
            this.btnKilepes = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnuKereses = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuKilepes = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(12, 31);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(335, 324);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txbdarab);
            this.groupBox1.Controls.Add(this.rbn2000utan);
            this.groupBox1.Controls.Add(this.rbn2000elott);
            this.groupBox1.Location = new System.Drawing.Point(13, 410);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(335, 183);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(170, 137);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "darab";
            // 
            // txbdarab
            // 
            this.txbdarab.Location = new System.Drawing.Point(16, 137);
            this.txbdarab.Name = "txbdarab";
            this.txbdarab.Size = new System.Drawing.Size(139, 22);
            this.txbdarab.TabIndex = 2;
            // 
            // rbn2000utan
            // 
            this.rbn2000utan.AutoSize = true;
            this.rbn2000utan.Location = new System.Drawing.Point(16, 94);
            this.rbn2000utan.Name = "rbn2000utan";
            this.rbn2000utan.Size = new System.Drawing.Size(164, 21);
            this.rbn2000utan.TabIndex = 1;
            this.rbn2000utan.TabStop = true;
            this.rbn2000utan.Text = "2000-ben vagy utána";
            this.rbn2000utan.UseVisualStyleBackColor = true;
            this.rbn2000utan.CheckedChanged += new System.EventHandler(this.rbn2000utan_CheckedChanged);
            // 
            // rbn2000elott
            // 
            this.rbn2000elott.AutoSize = true;
            this.rbn2000elott.Location = new System.Drawing.Point(16, 54);
            this.rbn2000elott.Name = "rbn2000elott";
            this.rbn2000elott.Size = new System.Drawing.Size(127, 21);
            this.rbn2000elott.TabIndex = 0;
            this.rbn2000elott.TabStop = true;
            this.rbn2000elott.Text = "2000 előtt épült";
            this.rbn2000elott.UseVisualStyleBackColor = true;
            this.rbn2000elott.CheckedChanged += new System.EventHandler(this.rbn2000elott_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(398, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Hely:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(401, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "Ország:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(401, 227);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "Hossz:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(401, 313);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(28, 17);
            this.label5.TabIndex = 5;
            this.label5.Text = "Év:";
            // 
            // txbHely
            // 
            this.txbHely.Location = new System.Drawing.Point(468, 57);
            this.txbHely.Name = "txbHely";
            this.txbHely.Size = new System.Drawing.Size(100, 22);
            this.txbHely.TabIndex = 6;
            // 
            // txbOrszag
            // 
            this.txbOrszag.Location = new System.Drawing.Point(468, 140);
            this.txbOrszag.Name = "txbOrszag";
            this.txbOrszag.Size = new System.Drawing.Size(100, 22);
            this.txbOrszag.TabIndex = 7;
            // 
            // txbHossz
            // 
            this.txbHossz.Location = new System.Drawing.Point(468, 221);
            this.txbHossz.Name = "txbHossz";
            this.txbHossz.Size = new System.Drawing.Size(100, 22);
            this.txbHossz.TabIndex = 8;
            // 
            // txbEv
            // 
            this.txbEv.Location = new System.Drawing.Point(468, 313);
            this.txbEv.Name = "txbEv";
            this.txbEv.Size = new System.Drawing.Size(100, 22);
            this.txbEv.TabIndex = 9;
            // 
            // btnKilepes
            // 
            this.btnKilepes.Location = new System.Drawing.Point(457, 504);
            this.btnKilepes.Name = "btnKilepes";
            this.btnKilepes.Size = new System.Drawing.Size(111, 33);
            this.btnKilepes.TabIndex = 10;
            this.btnKilepes.Text = "Kilépés";
            this.btnKilepes.UseVisualStyleBackColor = true;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuKereses,
            this.mnuKilepes});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 11;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mnuKereses
            // 
            this.mnuKereses.Name = "mnuKereses";
            this.mnuKereses.Size = new System.Drawing.Size(73, 24);
            this.mnuKereses.Text = "Keresés";
            this.mnuKereses.Click += new System.EventHandler(this.mnuKereses_Click);
            // 
            // mnuKilepes
            // 
            this.mnuKilepes.Name = "mnuKilepes";
            this.mnuKilepes.Size = new System.Drawing.Size(71, 24);
            this.mnuKilepes.Text = "Kilépés";
            this.mnuKilepes.Click += new System.EventHandler(this.btnKilepes);
            // 
            // frmFuggohidak1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 623);
            this.Controls.Add(this.btnKilepes);
            this.Controls.Add(this.txbEv);
            this.Controls.Add(this.txbHossz);
            this.Controls.Add(this.txbOrszag);
            this.Controls.Add(this.txbHely);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmFuggohidak1";
            this.Text = "Függőhidak";
            this.Load += new System.EventHandler(this.frmFuggohidak1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txbdarab;
        private System.Windows.Forms.RadioButton rbn2000utan;
        private System.Windows.Forms.RadioButton rbn2000elott;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txbHely;
        private System.Windows.Forms.TextBox txbOrszag;
        private System.Windows.Forms.TextBox txbHossz;
        private System.Windows.Forms.TextBox txbEv;
        private System.Windows.Forms.Button btnKilepes;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnuKereses;
        private System.Windows.Forms.ToolStripMenuItem mnuKilepes;
    }
}

