﻿
namespace Fuggohidak
{
    partial class frmFuggohidak2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbOrszag = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.ComboBox();
            this.chb1000 = new System.Windows.Forms.CheckBox();
            this.btnKereses = new System.Windows.Forms.Button();
            this.btnBezaras = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(38, 30);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(563, 324);
            this.listBox1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnBezaras);
            this.groupBox1.Controls.Add(this.btnKereses);
            this.groupBox1.Controls.Add(this.chb1000);
            this.groupBox1.Controls.Add(this.richTextBox1);
            this.groupBox1.Controls.Add(this.cmbOrszag);
            this.groupBox1.Location = new System.Drawing.Point(38, 394);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(563, 213);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Keresés";
            // 
            // cmbOrszag
            // 
            this.cmbOrszag.AutoSize = true;
            this.cmbOrszag.Location = new System.Drawing.Point(16, 45);
            this.cmbOrszag.Name = "cmbOrszag";
            this.cmbOrszag.Size = new System.Drawing.Size(58, 17);
            this.cmbOrszag.TabIndex = 0;
            this.cmbOrszag.Text = "Ország:";
            // 
            // richTextBox1
            // 
            this.richTextBox1.FormattingEnabled = true;
            this.richTextBox1.Location = new System.Drawing.Point(89, 45);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(141, 24);
            this.richTextBox1.TabIndex = 1;
            // 
            // chb1000
            // 
            this.chb1000.AutoSize = true;
            this.chb1000.Location = new System.Drawing.Point(19, 99);
            this.chb1000.Name = "chb1000";
            this.chb1000.Size = new System.Drawing.Size(164, 21);
            this.chb1000.TabIndex = 2;
            this.chb1000.Text = "1 km-nél hosszabbak";
            this.chb1000.UseVisualStyleBackColor = true;
            // 
            // btnKereses
            // 
            this.btnKereses.Location = new System.Drawing.Point(98, 147);
            this.btnKereses.Name = "btnKereses";
            this.btnKereses.Size = new System.Drawing.Size(85, 23);
            this.btnKereses.TabIndex = 3;
            this.btnKereses.Text = "Keresés";
            this.btnKereses.UseVisualStyleBackColor = true;
            this.btnKereses.Click += new System.EventHandler(this.btnKereses_Click_Click);
            // 
            // btnBezaras
            // 
            this.btnBezaras.Location = new System.Drawing.Point(275, 147);
            this.btnBezaras.Name = "btnBezaras";
            this.btnBezaras.Size = new System.Drawing.Size(75, 23);
            this.btnBezaras.TabIndex = 4;
            this.btnBezaras.Text = "Bezárás";
            this.btnBezaras.UseVisualStyleBackColor = true;
            this.btnBezaras.Click += new System.EventHandler(this.btnBezaras_Click);
            // 
            // frmFuggohidak2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(653, 633);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.listBox1);
            this.Name = "frmFuggohidak2";
            this.Text = "Keresés";
            this.Load += new System.EventHandler(this.frmFuggohidak2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnBezaras;
        private System.Windows.Forms.Button btnKereses;
        private System.Windows.Forms.CheckBox chb1000;
        private System.Windows.Forms.ComboBox richTextBox1;
        private System.Windows.Forms.Label cmbOrszag;
    }
}