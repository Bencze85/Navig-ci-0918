﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Kalapacsvetes
{
    //2. feladat
    public class Sportolo
    {
        public string helyezes { get; set; }
        public double eredmeny { get; set; }
        public string nev { get; set; }
        public string orszag { get; set; }
        public string helyszin { get; set; }
        public string datum { get; set; }

        public Sportolo (string sor)
        {
            string[] s = sor.Split(';');
            helyezes = s[0];
            eredmeny = Convert.ToDouble(s[1]);
            nev = s[2];
            orszag = s[3];
            helyszin = s[4];
            datum = s[5];
        }

    }
    class Kalapcsvetes
    {
        static void Main(string[] args)
        {
            //3. feladat
            List<Sportolo> lista = new List<Sportolo>();
            StreamReader sr = new StreamReader("kalapacsvetes.txt");
            string elsosor = sr.ReadLine();
            while (!sr.EndOfStream)
            {
                Sportolo sor = new Sportolo(sr.ReadLine());
                lista.Add(sor);
            }
            sr.Close();

            //4. feladat
            Console.WriteLine($"4. feladat: {lista.Count} dobás eredménye található");

            //5. feladat
            double eredmeny = 0;
            int magyarokSzama = 0;
            foreach (var item in lista)
            {
                if (item.orszag.Contains("HUN"))
                {
                    eredmeny += item.eredmeny;
                    magyarokSzama++;
                }
                double atlag = eredmeny / magyarokSzama;
                Console.WriteLine($"5. feladat: A magyar sportolók átlagosan {atlag:.##} métert dobtak");

                //6. feladat
                Console.WriteLine($"6. feladat: Adjon meg egy évszámot: ");
                string ev = Console.ReadLine();
                bool vanEv = false;
                int dobasokSzama = 0;
                var sportolok = new List<string>();
                foreach (var item in lista)
                {
                    if (item.datum.Substring(0, 4) == ev)
                    {
                        vanEv = true;
                        dobasokSzama++;
                        sportolok.Add(item.nev);
                    }
                }
                if (vanEv)
                {
                    Console.WriteLine($"\t{dobasokSzama} darab dobás került be ebben az évben");
                    foreach (var item in sportolok)
                    {
                        Console.WriteLine($"\t{item}");
                    }
                }
                else
                {
                    Console.WriteLine("\tEgy dobás sem került be ebben az évben");
                }

                //7. feladat
                Dictionary<string, int> statisztika = new Dictionary<string, int>();
                foreach (var kulcs in lista)
                {
                    if (statisztika.ContainsKey(kulcs.orszag))
                    {
                        statisztika[kulcs.orszag]++;
                    }
                    else
                    {
                        statisztika.Add(kulcs.orszag, 1);
                    }
                }
                Console.WriteLine("7. feladat: Statisztika");
                foreach (KeyValuePair<string, int> item in statisztika)
                {
                    Console.WriteLine($"\t{item.Key}-{item.Value} dobás");
                }
                //8. feladat
                StreamWriter sw = new StreamWriter("magyarok.txt");
                sw.WriteLine(elsosor);
                foreach (var item in lista)
                {
                    if (item.orszag.Contains("HUN"))
                    {
                        sw.WriteLine($"{item.helyezes};{item.eredmeny};{item.nev};{item.orszag};{item.helyszin};{item.datum}");
                    }
                }
                sw.Flush();
                sw.Close();
                Console.ReadKey();
            }
        }
    }
}
